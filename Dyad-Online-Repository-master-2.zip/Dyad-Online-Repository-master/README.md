# Dyad-Online-Repository
Log files and replication materials for paper titled: Stabilizing through randomizing: A bootstrap approach to estimating item validity and latent concepts
